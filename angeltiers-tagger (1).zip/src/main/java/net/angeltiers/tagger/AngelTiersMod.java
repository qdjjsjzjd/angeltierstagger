package net.angeltiers.tagger;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class AngelTiersMod implements ClientModInitializer {
    private static volatile boolean openGui = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "AngelTiers-refresh");
            t.setDaemon(true);
            return t;
        });
        ex.scheduleWithFixedDelay(TierData::refresh, 0, Math.max(1, Config.refreshMinutes), TimeUnit.MINUTES);

        // /angeltiers открывает окно настроек (экран открываем на следующем тике, когда чат уже закрыт)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("angeltiers").executes(ctx -> {
                    openGui = true;
                    return Command.SINGLE_SUCCESS;
                })));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (openGui) {
                openGui = false;
                mc.setScreen(new TierScreen(mc.screen));
            }
        });
    }
}
