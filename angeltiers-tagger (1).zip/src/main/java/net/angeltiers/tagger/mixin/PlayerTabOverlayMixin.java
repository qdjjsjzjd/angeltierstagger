package net.angeltiers.tagger.mixin;

import net.angeltiers.tagger.Config;
import net.angeltiers.tagger.TierData;
import net.minecraft.client.gui.components.PlayerTabOverlay;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerTabOverlay.class)
public abstract class PlayerTabOverlayMixin {
    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true, require = 0)
    private void angeltiers$tab(PlayerInfo info, CallbackInfoReturnable<Component> cir) {
        if (!Config.showInTab) return;
        String name = TierData.profileName(info.getProfile());
        if (name == null) return;
        Component c = TierData.decorate(name, cir.getReturnValue());
        if (c != null) cir.setReturnValue(c);
    }
}
