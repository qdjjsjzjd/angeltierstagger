package net.angeltiers.tagger.mixin;

import net.angeltiers.tagger.Config;
import net.angeltiers.tagger.TierData;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true, require = 0)
    private void angeltiers$decorate(CallbackInfoReturnable<Component> cir) {
        if (!Config.showAboveHead) return;
        Entity self = (Entity) (Object) this;
        if (self instanceof AbstractClientPlayer) {
            Component c = TierData.decorate(self.getName().getString(), cir.getReturnValue());
            if (c != null) cir.setReturnValue(c);
        }
    }
}
