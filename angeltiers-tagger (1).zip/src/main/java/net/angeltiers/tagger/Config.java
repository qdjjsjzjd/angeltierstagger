package net.angeltiers.tagger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class Config {
    public static volatile boolean enabled = true;
    public static volatile boolean showAboveHead = true;
    public static volatile boolean showInTab = true;
    public static volatile boolean showIcon = true;
    public static volatile String mode = "ALL";
    public static volatile int refreshMinutes = 10;

    private Config() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("angeltiers.json");
    }

    public static void load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                JsonObject o = JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                if (o.has("enabled")) enabled = o.get("enabled").getAsBoolean();
                if (o.has("showAboveHead")) showAboveHead = o.get("showAboveHead").getAsBoolean();
                if (o.has("showInTab")) showInTab = o.get("showInTab").getAsBoolean();
                if (o.has("showIcon")) showIcon = o.get("showIcon").getAsBoolean();
                if (o.has("mode")) mode = o.get("mode").getAsString().trim().toUpperCase(Locale.ROOT);
                if (o.has("refreshMinutes")) refreshMinutes = o.get("refreshMinutes").getAsInt();
            }
        } catch (Exception ignored) {
        }
        save();
    }

    public static void save() {
        try {
            JsonObject out = new JsonObject();
            out.addProperty("_help", "mode: ALL (лучший тир) или режим: DIAMONDPOT, NETHERITEPOT, BEAST, CARTPVP, CRYSTALPVP, NETHERSMP, DIAMONDSMP, UHC, AXE, MACE, SPEARMACE, OP, CREEPER. В игре: команда /angeltiers");
            out.addProperty("enabled", enabled);
            out.addProperty("showAboveHead", showAboveHead);
            out.addProperty("showInTab", showInTab);
            out.addProperty("showIcon", showIcon);
            out.addProperty("mode", mode);
            out.addProperty("refreshMinutes", refreshMinutes);
            Gson g = new GsonBuilder().setPrettyPrinting().create();
            Files.writeString(path(), g.toJson(out));
        } catch (Exception ignored) {
        }
    }
}
