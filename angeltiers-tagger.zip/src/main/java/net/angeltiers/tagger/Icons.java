package net.angeltiers.tagger;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;

import java.util.HashMap;
import java.util.Map;

/** Иконки китов: символы из шрифта angeltiers:icons (assets/angeltiers/font/icons.json). */
public final class Icons {
    private static final String[] ORDER = {
            "DIAMONDPOT", "NETHERITEPOT", "BEAST", "CARTPVP", "CRYSTALPVP", "NETHERSMP",
            "DIAMONDSMP", "UHC", "AXE", "MACE", "SPEARMACE", "OP", "CREEPER", "ROCKETMACE"
    };
    private static final Map<String, Component> CACHE = new HashMap<>();

    private Icons() {}

    public static Component of(String mode) {
        Component cached = CACHE.get(mode);
        if (cached != null) return cached;
        Component result = Component.empty();
        for (int i = 0; i < ORDER.length; i++) {
            if (ORDER[i].equals(mode)) {
                JsonObject o = new JsonObject();
                o.addProperty("text", String.valueOf((char) (0xE000 + i)));
                o.addProperty("font", "angeltiers:icons");
                result = ComponentSerialization.CODEC.parse(JsonOps.INSTANCE, o).result().orElse(Component.empty());
                break;
            }
        }
        CACHE.put(mode, result);
        return result;
    }
}
