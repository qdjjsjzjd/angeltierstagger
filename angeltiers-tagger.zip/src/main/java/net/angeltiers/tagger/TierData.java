package net.angeltiers.tagger;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class TierData {
    public static final String URL = "https://angeltiers.abrdns.com/players.json";
    private static final String[] TIERS = {"HT1", "LT1", "HT2", "LT2", "HT3", "LT3", "HT4", "LT4", "HT5", "LT5"};

    private static volatile Map<String, Map<String, String>> players = Map.of();

    private TierData() {}

    public static void refresh() {
        try {
            HttpClient c = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(8))
                    .followRedirects(HttpClient.Redirect.NORMAL)
                    .build();
            HttpRequest r = HttpRequest.newBuilder(URI.create(URL + "?t=" + System.currentTimeMillis()))
                    .timeout(Duration.ofSeconds(10))
                    .header("User-Agent", "AngelTiersTagger/1.0")
                    .GET().build();
            HttpResponse<String> resp = c.send(r, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) return;
            JsonArray arr = JsonParser.parseString(resp.body()).getAsJsonArray();
            Map<String, Map<String, String>> m = new HashMap<>();
            for (JsonElement e : arr) {
                JsonObject o = e.getAsJsonObject();
                if (!o.has("name")) continue;
                String name = o.get("name").getAsString().toLowerCase(Locale.ROOT);
                Map<String, String> t = new HashMap<>();
                if (o.has("tiers") && o.get("tiers").isJsonObject()) {
                    for (Map.Entry<String, JsonElement> en : o.getAsJsonObject("tiers").entrySet()) {
                        t.put(en.getKey().toUpperCase(Locale.ROOT), en.getValue().getAsString());
                    }
                }
                m.put(name, t);
            }
            players = m;
        } catch (Exception ignored) {
        }
    }

    private static int idx(String t) {
        String b = t.startsWith("R") ? t.substring(1) : t;
        for (int i = 0; i < TIERS.length; i++) if (TIERS[i].equals(b)) return i;
        return -1;
    }

    private static String pick(Map<String, String> t) {
        String mode = Config.mode;
        if (!"ALL".equals(mode)) {
            String v = t.get(mode);
            return v != null && idx(v) >= 0 ? v : null;
        }
        String best = null;
        int bi = 99;
        for (String v : t.values()) {
            int i = idx(v);
            if (i >= 0 && i < bi) {
                bi = i;
                best = v;
            }
        }
        return best;
    }

    private static int color(String t) {
        if (t.startsWith("R")) return 0xB794FF;
        return switch (t) {
            case "HT1" -> 0xFFD45A;
            case "LT1" -> 0xE6B13A;
            case "HT2" -> 0x6FB7FF;
            case "LT2" -> 0x7FA6D6;
            case "HT3" -> 0xF0A060;
            case "LT3" -> 0xD48650;
            case "HT4" -> 0xB5B9C4;
            case "LT4" -> 0x9A9EAA;
            case "HT5" -> 0x8A8F9C;
            default -> 0x7A7F8A;
        };
    }

    /** Возвращает имя с тиром впереди или null, если игрока нет в рейтинге. */
    public static Component decorate(String playerName, Component original) {
        if (!Config.enabled || playerName == null) return null;
        Map<String, String> t = players.get(playerName.toLowerCase(Locale.ROOT));
        if (t == null) return null;
        String tier = pick(t);
        if (tier == null) return null;
        String prefixText = "[" + tier + "] ";
        if (original.getString().startsWith(prefixText)) return null;
        MutableComponent prefix = Component.literal(prefixText)
                .withStyle(Style.EMPTY.withColor(color(tier)).withBold(true));
        return Component.empty().append(prefix).append(original);
    }

    /** Имя из GameProfile; работает и со старым (getName), и с новым (name) API. */
    public static String profileName(Object profile) {
        if (profile == null) return null;
        for (String m : new String[]{"name", "getName"}) {
            try {
                Object v = profile.getClass().getMethod(m).invoke(profile);
                if (v instanceof String s) return s;
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
