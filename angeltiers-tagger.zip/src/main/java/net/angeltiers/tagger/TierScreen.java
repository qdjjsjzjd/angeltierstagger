package net.angeltiers.tagger;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.ArrayList;
import java.util.List;

public class TierScreen extends Screen {
    private static final String[][] MODES = {
            {"ALL", "Лучший тир (по очкам)"},
            {"DIAMONDPOT", "DiaPot"}, {"NETHERITEPOT", "NethPot"},
            {"BEAST", "Beast"}, {"CARTPVP", "Cart"},
            {"CRYSTALPVP", "Crystal"}, {"NETHERSMP", "NethSMP"},
            {"DIAMONDSMP", "DiaSMP"}, {"UHC", "UHC"},
            {"AXE", "Axe"}, {"MACE", "Mace"},
            {"SPEARMACE", "SpearMace"}, {"OP", "OP"},
            {"CREEPER", "Creeper"}, {"ROCKETMACE", "RocketMace"}
    };

    private final Screen parent;
    private final List<Button> modeButtons = new ArrayList<>();

    public TierScreen(Screen parent) {
        super(Component.literal("AngelTiers"));
        this.parent = parent;
    }

    /** Кнопка режима: иконка кита + название, выбранный отмечен галочкой. */
    private static Component modeLabel(String[] m) {
        boolean on = m[0].equals(Config.mode);
        MutableComponent c = Component.empty();
        if (on) c.append(Component.literal("\u2714 ").withStyle(ChatFormatting.GREEN));
        if (!"ALL".equals(m[0])) c.append(Icons.of(m[0])).append(Component.literal(" "));
        c.append(Component.literal(m[1]).withStyle(on ? ChatFormatting.GREEN : ChatFormatting.WHITE));
        return c;
    }

    private static Component toggleLabel(String title, boolean v) {
        return Component.literal(title + ": " + (v ? "ВКЛ" : "ВЫКЛ"))
                .withStyle(v ? ChatFormatting.GREEN : ChatFormatting.RED);
    }

    private void select(String key) {
        Config.mode = key;
        for (int i = 0; i < modeButtons.size(); i++) {
            modeButtons.get(i).setMessage(modeLabel(MODES[i]));
        }
    }

    @Override
    protected void init() {
        modeButtons.clear();
        int cx = this.width / 2;
        int step = 19;
        int h = 18;
        int y = 28;

        addRenderableWidget(new StringWidget(cx - 100, 10, 200, 12,
                Component.literal("AngelTiers: какой тир показывать"), this.font));

        Button all = Button.builder(modeLabel(MODES[0]), b -> select(MODES[0][0]))
                .bounds(cx - 100, y, 200, h).build();
        addRenderableWidget(all);
        modeButtons.add(all);
        y += step;

        for (int i = 1; i < MODES.length; i++) {
            final String[] m = MODES[i];
            int col = (i - 1) % 2;
            int row = (i - 1) / 2;
            Button b = Button.builder(modeLabel(m), x -> select(m[0]))
                    .bounds(cx - 100 + col * 102, y + row * step, 98, h).build();
            addRenderableWidget(b);
            modeButtons.add(b);
        }
        y += ((MODES.length - 1 + 1) / 2) * step;

        addRenderableWidget(Button.builder(toggleLabel("Над головой", Config.showAboveHead), b -> {
            Config.showAboveHead = !Config.showAboveHead;
            b.setMessage(toggleLabel("Над головой", Config.showAboveHead));
        }).bounds(cx - 100, y, 98, h).build());

        addRenderableWidget(Button.builder(toggleLabel("В табе", Config.showInTab), b -> {
            Config.showInTab = !Config.showInTab;
            b.setMessage(toggleLabel("В табе", Config.showInTab));
        }).bounds(cx + 2, y, 98, h).build());
        y += step;

        addRenderableWidget(Button.builder(toggleLabel("Иконка кита", Config.showIcon), b -> {
            Config.showIcon = !Config.showIcon;
            b.setMessage(toggleLabel("Иконка кита", Config.showIcon));
        }).bounds(cx - 100, y, 200, h).build());
        y += step;

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(cx - 100, y, 200, h).build());
    }

    @Override
    public void onClose() {
        Config.save();
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }
}
